# Changelog

## [1.3.0](https://github.com/prefapp/features/compare/generator-v1.2.0...generator-v1.3.0) (2022-09-09)


### Features

* **generator:** Use component as generator input ([#100](https://github.com/prefapp/features/issues/100)) ([1f84a14](https://github.com/prefapp/features/commit/1f84a14c0873dfba6e1325e0fb1b7bd3f8c142e8))

## [1.2.0](https://github.com/prefapp/features/compare/generator-v1.1.0...generator-v1.2.0) (2022-09-08)


### Features

* Add special tags to avoid '{{}}' ([#84](https://github.com/prefapp/features/issues/84)) ([6cf8290](https://github.com/prefapp/features/commit/6cf829055cf561df1aa1a5df1d3fe78268a9e0e8))
* **generator:** Feature/generator args parser ([#95](https://github.com/prefapp/features/issues/95)) ([b067f9e](https://github.com/prefapp/features/commit/b067f9e54744a4ab1d187ffd19f7c319a31c6aab))

## [1.1.0](https://github.com/prefapp/features/compare/generator-v1.0.0...generator-v1.1.0) (2022-09-05)


### Features

* **generator:** Generate output.json ([#30](https://github.com/prefapp/features/issues/30)) ([1574ed1](https://github.com/prefapp/features/commit/1574ed18b8b852d74821ad54a0c19cf55eb935ed))

## 1.0.0 (2022-09-05)


### Features

* add initial setup ([#6](https://github.com/prefapp/features/issues/6)) ([1894afb](https://github.com/prefapp/features/commit/1894afb5a3ba3ccafe2e1ab3b7b8b4ca85f44644))
* **generator:** add config reader ([#16](https://github.com/prefapp/features/issues/16)) ([a7c55f8](https://github.com/prefapp/features/commit/a7c55f8ce9de39b7d7200691ec4a2b4a5370b677))
* **generator:** improve args parse ([#11](https://github.com/prefapp/features/issues/11)) ([b472541](https://github.com/prefapp/features/commit/b472541080a2cda40dd72b82011dddec5b9c50e8))
* **genertor:** bump 0.3.0 ([b86e81b](https://github.com/prefapp/features/commit/b86e81b749fe3a63ffcfda814a09d9274992d211))
* new generator version ([#8](https://github.com/prefapp/features/issues/8)) ([bf3cae5](https://github.com/prefapp/features/commit/bf3cae5de8adefd16374169cc1de34cbb2effb96))


### Bug Fixes

* **generator:** Update package.json ([#53](https://github.com/prefapp/features/issues/53)) ([5694a84](https://github.com/prefapp/features/commit/5694a842edade6220684ddfecfcfdde2f96d4103))
