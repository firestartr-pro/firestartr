const render = require('../lib/render')
const path = require('path')
const fs = require("fs")

describe("Render files in multiple directories",() => {

  it("should render file", async () => {

    try {

      const inputDir = path.join(__dirname, `fixtures`)

      await render(

        {

          inputDir: inputDir,

          outputDir: "/tmp",

          ctx: { test_render: "test_text" }

        }
      )

      const dirToDelete = `/tmp/test_should_render_files`

      expect(await _dirOrFileExists({path: dirToDelete})).toEqual(true)

      await _rmDir({dir: dirToDelete})

      expect(await _dirOrFileExists({path: dirToDelete})).toEqual(false)


    } catch(e) {

      console.error(e)

      console.error(e.stack)

      throw e
    }

  })

})

function _dirOrFileExists({path}){

  return new Promise((ok, ko) => {

    fs.exists(path, (cb) => {

      return ok(cb)

    })

  })

}

function _rmDir({dir}){

  return new Promise((ok, ko) => {

    fs.rm(dir, { recursive: true, force: true }, (err) => {

      if(err)
        return ko(`Deleting ${dir}: ${err}`)
      else
        return ok(`Directory "${dir}" has been removed`)

    })

  })

}
