#!/usr/local/bin/node

const render = require('./lib/render')
const configRender = require("./lib/config-render.js")
const commandLineArgs = require('command-line-args')
const path = require("path")
const fs = require("fs")
const yaml = require("js-yaml")
const argsRender = require("./lib/args_render.js")

const optionDefinitions = [
  { name: 'inputDir', alias: 'i', type: String, defaultValue: process.env["PWD"] },
  { name: 'outputDir', alias: 'o', type: String},
  { name: 'componentFile', alias: 'c', type: String}
]

try{

  const options = commandLineArgs(optionDefinitions)

  if(!options["inputDir"] || !options["outputDir"] || !options["componentFile"]){
    throw `inputDir, outputDir and componentFile are necessary`
  }

  const ctx = __loadCtx(options)

  render({
    inputDir: path.join(options.inputDir, "templates"),
    outputDir: options.outputDir,
    ctx
  })

    .then((filesList) => {
    
      configRender({

        configPath: path.join(options.inputDir, "config.yaml"),

        outputDir: options.outputDir,

        filesList

      })

    })

}
catch(err){
  console.error(err)
  process.exit(1)
}

/*
 * Loads the component and the config and parses the arguments declared by the feature
 *
 * Returns an object with the context.
 *
 */
function __loadCtx({componentFile, inputDir}){

  const component = yaml.load(Buffer.from(fs.readFileSync(componentFile).toString()))

  const config = yaml.load(Buffer.from(fs.readFileSync(path.join(inputDir, "config.yaml")).toString()))

  return argsRender(

    component, 

    config

  ) 

}
