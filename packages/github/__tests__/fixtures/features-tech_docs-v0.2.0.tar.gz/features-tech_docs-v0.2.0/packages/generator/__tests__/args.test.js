const attrReader = require("../lib/args_render.js")

describe("The config parser", function(){

  it("can retrieve args", function(){


    const source = {

      metadata: {

        name: "foo",

        annotations:{
          a: "A",

          b: "B"
        },


      },

      spec: {

        type: "TEST",

        provisioner: {

          features: [

            {
              name: "example",
              version: "1.2.0",
              args: {

                lang: "jp"

              }

            }

          ]

        }

      }

    }


    let result = attrReader(source, {

      feature_name: "example",

      args: {

        NAME: {
          $ref: "metadata.name"
        },

        A: {

          $ref: "metadata.annotations.a"
        },

        LANG: {

          $lit: "lang"

        }

      }

    })


    console.log("RESULT >", result)

    expect(result.NAME).toBe("foo")

    expect(result.A).toBe("A")

    expect(result.LANG).toBe("jp")

  })


})
