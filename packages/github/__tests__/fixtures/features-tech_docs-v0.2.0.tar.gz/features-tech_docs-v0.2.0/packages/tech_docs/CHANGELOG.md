# Changelog

## [0.2.0](https://github.com/prefapp/features/compare/tech_docs-v0.1.0...tech_docs-v0.2.0) (2023-04-17)


### Features

* Feature/add tech docs ([#148](https://github.com/prefapp/features/issues/148)) ([8161681](https://github.com/prefapp/features/commit/8161681ffc1afa4417d46ae23eca45863c867abd))
