# Changelog

## [2.18.0](https://github.com/prefapp/features/compare/example-v2.17.0...example-v2.18.0) (2023-04-17)


### Features

* test ([4d38e4d](https://github.com/prefapp/features/commit/4d38e4d3c7cf52b8b9bcffc21e146445226cfa6e))

## [2.17.0](https://github.com/prefapp/features/compare/example-v2.16.0...example-v2.17.0) (2022-09-19)


### Features

* **example:** Update config.yaml ([#128](https://github.com/prefapp/features/issues/128)) ([38b2683](https://github.com/prefapp/features/commit/38b26833d967bf457f8f340c9f7be1cbba933b60))

## [2.16.0](https://github.com/prefapp/features/compare/example-v2.15.0...example-v2.16.0) (2022-09-15)


### Features

* **example:** change workflow values ([e067f63](https://github.com/prefapp/features/commit/e067f63977da42c94749424f8915f7afc3bd4b22))

## [2.15.0](https://github.com/prefapp/features/compare/example-v2.14.1...example-v2.15.0) (2022-09-13)


### Features

* update version ([997e28e](https://github.com/prefapp/features/commit/997e28e1429ab6aa7f2be957213daa6d5a79cf8b))

## [2.14.1](https://github.com/prefapp/features/compare/example-v2.14.0...example-v2.14.1) (2022-09-12)


### Bug Fixes

* **example:** $ mark in yaml ([92b631b](https://github.com/prefapp/features/commit/92b631b917e5c8f672fe6248ac49035d41683a86))
* **installer:** Modify example yaml $ mark ([1f8972a](https://github.com/prefapp/features/commit/1f8972ab9128c00e8aa039062cf1e507cb158c88))

## [2.14.0](https://github.com/prefapp/features/compare/example-v2.13.0...example-v2.14.0) (2022-09-12)


### Features

* **example:** update yaml example ([ff3339e](https://github.com/prefapp/features/commit/ff3339e93e00991e00c8a92c42d7b5cdc6344e3a))

## [2.13.0](https://github.com/prefapp/features/compare/example-v2.12.0...example-v2.13.0) (2022-09-12)


### Features

* Feature/modify config.yaml structure ([#119](https://github.com/prefapp/features/issues/119)) ([6048402](https://github.com/prefapp/features/commit/604840260ce2ce95be6993bc393795aba8e304a9))

## [2.12.0](https://github.com/prefapp/features/compare/example-v2.11.0...example-v2.12.0) (2022-09-09)


### Features

* **example:** update config ([4e3b6e4](https://github.com/prefapp/features/commit/4e3b6e4179a49ebfa6d20de74f2d90fc9e0dfef5))

## [2.11.0](https://github.com/prefapp/features/compare/example-v2.10.0...example-v2.11.0) (2022-09-09)


### Features

* new release ([eb56766](https://github.com/prefapp/features/commit/eb5676679868d91c4a0cc1751e09d2c29c6145de))

## [2.10.0](https://github.com/prefapp/features/compare/example-v2.9.0...example-v2.10.0) (2022-09-09)


### Features

* **example:** Stopped using version generator ([0a23744](https://github.com/prefapp/features/commit/0a237443713b594a6dc87f75e437a1bb4d3a2608))

## [2.9.0](https://github.com/prefapp/features/compare/example-v2.8.1...example-v2.9.0) (2022-09-09)


### Features

* **example:** Prepare example for generator@1.3.0 ([#102](https://github.com/prefapp/features/issues/102)) ([372f5b8](https://github.com/prefapp/features/commit/372f5b889a0529043dffbc004a8f05b934e9b20c))
* **generator:** Modify config yaml structure ([#98](https://github.com/prefapp/features/issues/98)) ([7bbf944](https://github.com/prefapp/features/commit/7bbf9449174db42f8b650fde29df6a2a233f1cd3))

## [2.8.1](https://github.com/prefapp/features/compare/example-v2.8.0...example-v2.8.1) (2022-09-07)


### Bug Fixes

* **example:** set tests folder ([#93](https://github.com/prefapp/features/issues/93)) ([3a33b8b](https://github.com/prefapp/features/commit/3a33b8bfe9d0ff1254c04f293885113ae4c802b8))

## [2.8.0](https://github.com/prefapp/features/compare/example-v2.7.1...example-v2.8.0) (2022-09-07)


### Features

* **example:** add tests ([#86](https://github.com/prefapp/features/issues/86)) ([0450731](https://github.com/prefapp/features/commit/04507319527b5a7c7c51ce2a110941bac6a8699b))
* **example:** bump generator@1.2.0 ([#88](https://github.com/prefapp/features/issues/88)) ([b1e674a](https://github.com/prefapp/features/commit/b1e674a575e34faf1bd4617afe6c6df2ed52d183))

## [2.7.1](https://github.com/prefapp/features/compare/example-v2.7.0...example-v2.7.1) (2022-09-06)


### Bug Fixes

* **example:** blank spaces ([6c8534a](https://github.com/prefapp/features/commit/6c8534a705e97666656245f8d8d96d2c29c4d5d6))

## [2.7.0](https://github.com/prefapp/features/compare/example-v2.6.2...example-v2.7.0) (2022-09-05)


### Features

* **generator:** Generate output.json ([#30](https://github.com/prefapp/features/issues/30)) ([1574ed1](https://github.com/prefapp/features/commit/1574ed18b8b852d74821ad54a0c19cf55eb935ed))

## [2.6.2](https://github.com/prefapp/features/compare/example-v2.6.1...example-v2.6.2) (2022-09-05)


### Bug Fixes

* **example:** Update package.json ([#51](https://github.com/prefapp/features/issues/51)) ([f3f4ee8](https://github.com/prefapp/features/commit/f3f4ee84301988d5ba8c5d89670dd1c7fcf54644))

## [2.6.1](https://github.com/prefapp/features/compare/example-v2.6.0...example-v2.6.1) (2022-09-05)


### Bug Fixes

* **example:** Update package.json ([#49](https://github.com/prefapp/features/issues/49)) ([9b1f6c9](https://github.com/prefapp/features/commit/9b1f6c9e8c045b57b982d42cf2f3a61c3375058c))

## [2.6.0](https://github.com/prefapp/features/compare/example-v2.5.0...example-v2.6.0) (2022-09-05)


### Features

* **example:** test ([beb0912](https://github.com/prefapp/features/commit/beb09126865b476ebd428f276fd54e8d3e34c963))


### Bug Fixes

* **example:** Update config.yaml ([#47](https://github.com/prefapp/features/issues/47)) ([b1613cd](https://github.com/prefapp/features/commit/b1613cd301987dee44350243ace1ac94b18d3cc2))

## [2.5.0](https://github.com/prefapp/features/compare/example-v2.4.0...example-v2.5.0) (2022-08-31)


### Features

* **example:** Update config.yaml ([#25](https://github.com/prefapp/features/issues/25)) ([6af2ba7](https://github.com/prefapp/features/commit/6af2ba71396edd199ee20e9707c9b105fea24181))
* **example:** Update config.yaml ([#27](https://github.com/prefapp/features/issues/27)) ([bbe40f7](https://github.com/prefapp/features/commit/bbe40f76639f6161eaf5ae1e2e81834ed95f4c5c))

## [2.4.0](https://github.com/prefapp/features/compare/example-v2.3.0...example-v2.4.0) (2022-08-31)


### Features

* **example:** Update config.yaml ([#23](https://github.com/prefapp/features/issues/23)) ([e90cf88](https://github.com/prefapp/features/commit/e90cf88d041afd8b713e1b92b84cdb5782dd3533))

## [2.3.0](https://github.com/prefapp/features/compare/example-v2.2.0...example-v2.3.0) (2022-08-31)


### Features

* **example:** Update config.yaml ([#21](https://github.com/prefapp/features/issues/21)) ([028a2fd](https://github.com/prefapp/features/commit/028a2fdbe117c088d64de460b72ae13ca238fe99))

## [2.2.0](https://github.com/prefapp/features/compare/example-v2.1.0...example-v2.2.0) (2022-08-30)


### Features

* **example:** upgrade generator ([#17](https://github.com/prefapp/features/issues/17)) ([484164f](https://github.com/prefapp/features/commit/484164ff8146dbe3765e2b88b59ebcbb0298999d))

## [2.1.0](https://github.com/prefapp/features/compare/example-v2.0.0...example-v2.1.0) (2022-08-26)


### Features

* add examples config ([#13](https://github.com/prefapp/features/issues/13)) ([8930930](https://github.com/prefapp/features/commit/89309309e1ec54a89ca5757e676dda610178abdb))
* new generator version ([#12](https://github.com/prefapp/features/issues/12)) ([90ba103](https://github.com/prefapp/features/commit/90ba10368cb27534adc2f78cd149baf98670acbe))

## [2.0.0](https://github.com/prefapp/features/compare/example-v1.0.0...example-v2.0.0) (2022-08-26)


### ⚠ BREAKING CHANGES

* **example:** add generator as dep (#9)

### Features

* **example:** add generator as dep ([#9](https://github.com/prefapp/features/issues/9)) ([ff495f8](https://github.com/prefapp/features/commit/ff495f8e9ab089b8d21771af903d2acebb3d9dae))

## 1.0.0 (2022-08-26)


### Features

* add initial setup ([#6](https://github.com/prefapp/features/issues/6)) ([1894afb](https://github.com/prefapp/features/commit/1894afb5a3ba3ccafe2e1ab3b7b8b4ca85f44644))
