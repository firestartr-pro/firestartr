const fs = require("fs")
const path = require("path")

const { exec } = require("child_process")

describe("Example", function(){

  it("can be rendered", async () => {

    fs.mkdirSync("/tmp/features")
    fs.mkdirSync("/tmp/features/output")
    fs.mkdirSync("/tmp/features/output/example")

    fs.writeFileSync("/tmp/features/.env", `NAME=prefapp`)

    return new Promise((ok, ko) => {

      exec(`npm run generate -- --outputDir=/tmp/features/output/example --componentFile=${path.join(__dirname, 'fixtures/component.yaml')}`, (error, stdout, stderr) => {

        if(error)
          ko(error)
        else
          ok()

      })

    }).then(() => {

      expect(fs.existsSync("/tmp/features/output/example/output.json")).toEqual(true)

      const output = JSON.parse(fs.readFileSync("/tmp/features/output/example/output.json"))

      expect(Array.isArray(output.files)).toEqual(true)

      const file = Buffer.from(fs.readFileSync(output.files[0].localPath)).toString()

      console.log(file)

      expect(file.search("echo hola prefapp") != -1).toEqual(true)

    })

  })



})
