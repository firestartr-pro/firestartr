# Changelog

## [1.14.0](https://github.com/prefapp/features/compare/installer-v1.13.5...installer-v1.14.0) (2023-04-17)


### Features

* test ([033c392](https://github.com/prefapp/features/commit/033c3926b36f2e729838654db5fbf3e7ddb133ea))
* test-2 ([465a3a0](https://github.com/prefapp/features/commit/465a3a0b74dffac535f8daff15dea84a2dce51c8))


### Bug Fixes

* test ([02e6178](https://github.com/prefapp/features/commit/02e6178f37a39dfb20712580a239908ff4b644d6))

### [1.13.5](https://www.github.com/prefapp/features/compare/installer-v1.13.4...installer-v1.13.5) (2022-11-07)


### Bug Fixes

* test ([243c136](https://www.github.com/prefapp/features/commit/243c136a463828c287dfe6c5b28ff770e2089e5a))

### [1.13.4](https://www.github.com/prefapp/features/compare/installer-v1.13.3...installer-v1.13.4) (2022-11-07)


### Bug Fixes

* test new package publish ([b7fa382](https://www.github.com/prefapp/features/commit/b7fa382984cc6b65bcdcd6b926bc6cf7c8530433))

## [1.13.3](https://github.com/prefapp/features/compare/installer-v1.13.2...installer-v1.13.3) (2022-10-19)


### Bug Fixes

* Change env var name ([0fdff9b](https://github.com/prefapp/features/commit/0fdff9bd4586197e98ebca01f373f6160467f80a))

## [1.13.2](https://github.com/prefapp/features/compare/installer-v1.13.1...installer-v1.13.2) (2022-10-03)


### Bug Fixes

* **installer:** Changed token for auth ([c665a08](https://github.com/prefapp/features/commit/c665a08436f651d841b63850dc29efe1ba8eb676))

## [1.13.1](https://github.com/prefapp/features/compare/installer-v1.13.0...installer-v1.13.1) (2022-09-29)


### Bug Fixes

* add list_features.js to bien executable ([b6f43ec](https://github.com/prefapp/features/commit/b6f43ec54485f8e1fbfe810e6de0439e88b9061f))
* Grant exec permission ([a575037](https://github.com/prefapp/features/commit/a575037f41b2dccb266d4df8850dc2169dcd1fd9))

## [1.13.0](https://github.com/prefapp/features/compare/installer-v1.12.1...installer-v1.13.0) (2022-09-26)


### Features

* **installer:** add list-features command ([#131](https://github.com/prefapp/features/issues/131)) ([3aa37a2](https://github.com/prefapp/features/commit/3aa37a2a908a08fd2463102327489c4b12e02478))

## [1.12.1](https://github.com/prefapp/features/compare/installer-v1.12.0...installer-v1.12.1) (2022-09-13)


### Bug Fixes

* **installer:** validate env var TOKEN exists ([#124](https://github.com/prefapp/features/issues/124)) ([d922555](https://github.com/prefapp/features/commit/d92255591f08e2b41d7ffc4c31cdc49f2ae58e70))

## [1.12.0](https://github.com/prefapp/features/compare/installer-v1.11.0...installer-v1.12.0) (2022-09-09)


### Features

* **installer:** Update README.md ([#116](https://github.com/prefapp/features/issues/116)) ([0f3afb5](https://github.com/prefapp/features/commit/0f3afb585d5f2b67da2c07736bea4e62b7d1ac43))

## [1.11.0](https://github.com/prefapp/features/compare/installer-v1.10.0...installer-v1.11.0) (2022-09-09)


### Features

* **installer:** Update param for component file ([cb69779](https://github.com/prefapp/features/commit/cb69779d36d7ad51db60ecc9b874451b1e31790d))


### Bug Fixes

* **installer:** Non working installer ([d955de5](https://github.com/prefapp/features/commit/d955de5cffb45c26a5a604f31b45d5ac9bd62652))

## [1.10.0](https://github.com/prefapp/features/compare/installer-v1.9.0...installer-v1.10.0) (2022-09-08)


### Features

* **generator:** Feature/generator args parser ([#95](https://github.com/prefapp/features/issues/95)) ([b067f9e](https://github.com/prefapp/features/commit/b067f9e54744a4ab1d187ffd19f7c319a31c6aab))

## [1.9.0](https://github.com/prefapp/features/compare/installer-v1.8.0...installer-v1.9.0) (2022-09-07)


### Features

* Add pr verify ([#89](https://github.com/prefapp/features/issues/89)) ([10c99d2](https://github.com/prefapp/features/commit/10c99d259bc9117813e624e7add67d2c5b78fb68))

## [1.8.0](https://github.com/prefapp/features/compare/installer-v1.7.3...installer-v1.8.0) (2022-09-07)


### Features

* **installer:** Add env param for interpolation ([98c40df](https://github.com/prefapp/features/commit/98c40df2ce74ac181db4b79b4559d4c3012e64ac))

## [1.7.3](https://github.com/prefapp/features/compare/installer-v1.7.2...installer-v1.7.3) (2022-09-06)


### Bug Fixes

* **installer:** Fixed path of the script ([e75cb6e](https://github.com/prefapp/features/commit/e75cb6edce396e4afa2c4c2f9052e0374d36bd44))

## [1.7.2](https://github.com/prefapp/features/compare/installer-v1.7.1...installer-v1.7.2) (2022-09-06)


### Bug Fixes

* **installer:** Add compatibility with render ([5f44728](https://github.com/prefapp/features/commit/5f4472815391d2ce0fa4ec90dbc1cc673f8e9c8a))

## [1.7.1](https://github.com/prefapp/features/compare/installer-v1.7.0...installer-v1.7.1) (2022-09-06)


### Bug Fixes

* **installer:** remove unknown dependency ([cae6176](https://github.com/prefapp/features/commit/cae6176e213de61417f7bda26675101fbaec95c8))

## [1.7.0](https://github.com/prefapp/features/compare/installer-v1.6.0...installer-v1.7.0) (2022-09-06)


### Features

* **installer:** Update README.md ([#75](https://github.com/prefapp/features/issues/75)) ([9d86e02](https://github.com/prefapp/features/commit/9d86e025bbd8348f6e4b00e87435c7af644d7b13))

## [1.6.0](https://github.com/prefapp/features/compare/installer-v1.5.0...installer-v1.6.0) (2022-09-06)


### Features

* **installer:** Add bin to package.json ([6e6dc20](https://github.com/prefapp/features/commit/6e6dc20bfbfcfdae5cfdd449a790e20c1938dd15))

## [1.5.0](https://github.com/prefapp/features/compare/installer-v1.4.8...installer-v1.5.0) (2022-09-06)


### Features

* **installer:** Add path as parameter ([ae4ec37](https://github.com/prefapp/features/commit/ae4ec37e9f86152c8142a0ec76c3d16fdea020f0))

## [1.4.8](https://github.com/prefapp/features/compare/installer-v1.4.7...installer-v1.4.8) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#65](https://github.com/prefapp/features/issues/65)) ([11dc8b3](https://github.com/prefapp/features/commit/11dc8b335ee42e25b7be5bbc70043538bfa056f8))

## [1.4.7](https://github.com/prefapp/features/compare/installer-v1.4.6...installer-v1.4.7) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#63](https://github.com/prefapp/features/issues/63)) ([9919072](https://github.com/prefapp/features/commit/9919072f257a67d45221fc22f81d0f9d5bb8d09d))

## [1.4.6](https://github.com/prefapp/features/compare/installer-v1.4.5...installer-v1.4.6) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#61](https://github.com/prefapp/features/issues/61)) ([715389c](https://github.com/prefapp/features/commit/715389cb5b3a7f62a4afd083695e905d7931fdd7))

## [1.4.5](https://github.com/prefapp/features/compare/installer-v1.4.4...installer-v1.4.5) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#59](https://github.com/prefapp/features/issues/59)) ([5524dd6](https://github.com/prefapp/features/commit/5524dd6500ff02b1941ce80958e04b575abcb246))

## [1.4.4](https://github.com/prefapp/features/compare/installer-v1.4.3...installer-v1.4.4) (2022-09-05)


### Bug Fixes

* **installer:** Create .npmrc ([#57](https://github.com/prefapp/features/issues/57)) ([96c3d13](https://github.com/prefapp/features/commit/96c3d139c1be6dd153d89095ce5c653476997db5))

## [1.4.3](https://github.com/prefapp/features/compare/installer-v1.4.2...installer-v1.4.3) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#45](https://github.com/prefapp/features/issues/45)) ([37fc3f1](https://github.com/prefapp/features/commit/37fc3f1b32126528f4ee576ad479a1bae6863614))

## [1.4.2](https://github.com/prefapp/features/compare/installer-v1.4.1...installer-v1.4.2) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#43](https://github.com/prefapp/features/issues/43)) ([93e1edc](https://github.com/prefapp/features/commit/93e1edc8ffef12a85e48720879ae3f17451ce75e))

## [1.4.1](https://github.com/prefapp/features/compare/installer-v1.4.0...installer-v1.4.1) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#41](https://github.com/prefapp/features/issues/41)) ([56eb1fc](https://github.com/prefapp/features/commit/56eb1fc1a1ef08071c6c7011408af93c8760ae3d))

## [1.4.0](https://github.com/prefapp/features/compare/installer-v1.3.1...installer-v1.4.0) (2022-09-05)


### Features

* **installer:** Add installer ([#28](https://github.com/prefapp/features/issues/28)) ([bc59ab8](https://github.com/prefapp/features/commit/bc59ab8d1270ba21272a37c1f039c02575ca0c53))
* **installer:** Update index.js ([#32](https://github.com/prefapp/features/issues/32)) ([03f27d5](https://github.com/prefapp/features/commit/03f27d5dd9f38da514577e11e8e5925c92f789dd))
* **installer:** Update index.js ([#35](https://github.com/prefapp/features/issues/35)) ([a040855](https://github.com/prefapp/features/commit/a040855e0b51d4ffeee82df33e4488b0af9e0df5))


### Bug Fixes

* **installer:** Update index.js ([#38](https://github.com/prefapp/features/issues/38)) ([2a6d876](https://github.com/prefapp/features/commit/2a6d87610b71d461ff2ba0f2522b2261d30cfaea))

## [1.3.1](https://github.com/prefapp/features/compare/installer-v1.3.0...installer-v1.3.1) (2022-09-05)


### Bug Fixes

* **installer:** Update index.js ([#38](https://github.com/prefapp/features/issues/38)) ([2a6d876](https://github.com/prefapp/features/commit/2a6d87610b71d461ff2ba0f2522b2261d30cfaea))

## [1.3.0](https://github.com/prefapp/features/compare/installer-v1.2.0...installer-v1.3.0) (2022-09-05)


### Features

* **installer:** Add installer ([#28](https://github.com/prefapp/features/issues/28)) ([bc59ab8](https://github.com/prefapp/features/commit/bc59ab8d1270ba21272a37c1f039c02575ca0c53))
* **installer:** Update index.js ([#32](https://github.com/prefapp/features/issues/32)) ([03f27d5](https://github.com/prefapp/features/commit/03f27d5dd9f38da514577e11e8e5925c92f789dd))
* **installer:** Update index.js ([#35](https://github.com/prefapp/features/issues/35)) ([a040855](https://github.com/prefapp/features/commit/a040855e0b51d4ffeee82df33e4488b0af9e0df5))

## [1.2.0](https://github.com/prefapp/features/compare/installer-v1.1.0...installer-v1.2.0) (2022-09-05)


### Features

* **installer:** Update index.js ([#35](https://github.com/prefapp/features/issues/35)) ([a040855](https://github.com/prefapp/features/commit/a040855e0b51d4ffeee82df33e4488b0af9e0df5))

## [1.1.0](https://github.com/prefapp/features/compare/installer-v1.0.0...installer-v1.1.0) (2022-09-05)


### Features

* **installer:** Update index.js ([#32](https://github.com/prefapp/features/issues/32)) ([03f27d5](https://github.com/prefapp/features/commit/03f27d5dd9f38da514577e11e8e5925c92f789dd))

## 1.0.0 (2022-09-05)


### Features

* **installer:** Add installer ([#28](https://github.com/prefapp/features/issues/28)) ([bc59ab8](https://github.com/prefapp/features/commit/bc59ab8d1270ba21272a37c1f039c02575ca0c53))
