#!/usr/local/bin/node

const {Octokit} = require("@octokit/rest")
const { pipeline } = require("stream")
const { writeFileSync } = require("fs");
const  util  = require ("util");
const execSync = require('child_process').execSync;


const commandLineArgs = require('command-line-args')
// Test release 11
const optionDefinitions = [
  { name: 'feature', alias: 'f', type: String},
  { name: 'version', alias: 'v', type: String},
  { name: 'path', alias: 'p', type: String, defaultValue: "/tmp/features"},
  { name: 'componentFile', alias: 'c', type: String}
]

const github_token = process.env["TOKEN"]

if(!github_token){
  console.error(`An env var TOKEN is needed to perform installations`)
  process.exit(1)
}


const octokit = new Octokit({

  auth: github_token

})


async function listReleases({repo}){

  if(releases) return releases

  releases = await octokit.rest.repos.listReleases({

    owner: "prefapp",
    repo

  })

  releases = releases.data

  return releases

}

async function getRelease({repo, feature, version}){

  const releases = await listReleases({repo})

  const r = releases.filter(r => r.name === `${feature}: v${version}`)[0]

  return r

}

async function getReleaseTarball({repo, feature, version}){

  const r = await getRelease({repo, feature, version})


  return r["tag_name"]

}

async function downloadReleaseTarball({owner, repo, feature, version, fileName}){

  const token = process.env.TOKEN;

  const ref = await getReleaseTarball({repo, feature, version})

  const response = await octokit.request(`GET /repos/${owner}/${repo}/tarball/${ref}`, {
      owner: 'OWNER',
      repo: 'REPO',
      ref: 'REF'
    })

  writeFileSync(fileName, Buffer.from(response.data));

  //Unzip using linux command

  try {
    let stdOut= execSync(`tar -xvf ${fileName} --directory ${OUTPUT_DIR}/installed`)
    console.log("Extracting feature...");
  }
  catch (err){
    console.log("output",err)
    console.log("sdterr",err.stderr.toString())
  }

  return;


}


function installFeature()
{

  //Get folder name
  const folderName = fs.readdirSync(`${necessaryFolder[1]}`)[0]
  const folderPath = `${necessaryFolder[1]}/${folderName}`


  //Create folder path
  if (!fs.existsSync(folderPath)){
    fs.mkdirSync(folderPath);
  }


  //Install the package with npm install

  try {

    let stdOut= execSync(`cd ${folderPath} && npm install && npm run generate -w packages/${options["feature"]} -- --outputDir=${OUTPUT_DIR}/output/${options["feature"]} --componentFile=${options["componentFile"]}`)
    console.log(stdOut.toString());
  }
  catch (err){
    console.log("output",err.toString())
    console.log("sdterr",err.stderr.toString())
  }




}


async function mainExecution()
{
  await downloadReleaseTarball({owner: "prefapp", repo: "features", feature: options["feature"], version: options["version"], fileName: `${OUTPUT_DIR}/feature.tar.gz`})
  installFeature()
}







const options = commandLineArgs(optionDefinitions)
let releases = false
const OUTPUT_DIR = options["path"]

//Create necessary folders
var fs = require('fs');
const necessaryFolder = [`${OUTPUT_DIR}/`, `${OUTPUT_DIR}/installed`, `${OUTPUT_DIR}/output/${options["feature"]}`]

for (const folder of necessaryFolder) {
  if (!fs.existsSync(folder)){
    fs.mkdirSync(folder, { recursive: true });
  }
}

try{
  if(!options["feature"] || !options["version"]){
    throw `feature and version are necessary`
  }

  if (!options["componentFile"]){
    throw `path for the component file is necessary`
  }

  console.log("Feature: " + options["feature"])
  console.log("Version: " + options["version"])
  console.log("Component path: " + options["componentFile"])



} catch(err){
    console.error(err)
    process.exit(1)
}

mainExecution()
