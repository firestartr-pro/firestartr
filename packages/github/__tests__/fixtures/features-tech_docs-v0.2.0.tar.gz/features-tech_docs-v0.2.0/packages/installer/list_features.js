#!/usr/local/bin/node

const {Octokit} = require("@octokit/rest")

function listReleases({owner = "prefapp", repo = "features"}){

  const github_token = process.env["GITHUB_TOKEN"]
  
  if(!github_token){
    console.error(`An env var TOKEN is needed to perform listing tasks`)
    process.exit(1)
  }

  const octokit = new Octokit({

    auth: github_token

  })
  
  octokit.rest.repos.getContent({

    owner,

    repo,

    path: ".release-please-manifest.json"


  }).then((response) => {

    return Buffer.from(response.data.content).toString('ascii')

        .replace(/\n/g, '')
        

  }).then((file) => {

    return Buffer.from(file, 'base64').toString('utf-8')

  }).then((list) => {

    console.log(list)

  })
  
}

listReleases({})
