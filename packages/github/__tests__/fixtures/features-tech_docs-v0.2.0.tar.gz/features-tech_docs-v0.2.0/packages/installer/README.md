
# Installer package          

This is the **installer** package. This package allow us to download a feature
from our feature repo and render it to an output location. 





## Usage

The command is the following:

* `npm run install-feature -- --feature=${FEATURE_NAME} --version=${FEATURE_VERSION} --path=${OUTPUT_PATH}`

### Parameter definition

| Name          | Type   | Description                                                                                             |
|---------------|--------|---------------------------------------------------------------------------------------------------------|
| **--feature** | string | Name of the feature to be installed                                                                     |
| **--version** | string | Version of the feature to be installed                                                                  |
| **--path**    | string | _[OPTIONAL] The output path where the feature will be rendered. The default value is **/tmp/features**_ |
| **--envFile** | string | _[OPTIONAL] The env file used for interpolation. The default value is **./.env**_                       |
