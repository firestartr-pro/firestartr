# Features mono-repo

This is the "features" mono repo for all the installable features of the Firestarter Backstage App, as well as the feature installator. The repo has the following components:

* Generator
* Installer
* Example feature

The features are based in templates that can be generated usin Nunjucks. Each feature can be rendered with the Generator, according to what the component may need. The mono-repo is also used for versioning of the features.

## Generator

This component is in charge of rendering the templates in the specific feature using Nunjucks. It receives the specific name of the feature, en input parameters and generate the template files.

## Installer

This component is responsible of installing the feature. It receives the name and version of the features to be installed, and the args we want to render. It then calls the generator to create the files and saves them in a specific folder.

## Example

This feature is an example one used for testing purposes only. It is an example Github Workflow, where we can interpolate some values.
