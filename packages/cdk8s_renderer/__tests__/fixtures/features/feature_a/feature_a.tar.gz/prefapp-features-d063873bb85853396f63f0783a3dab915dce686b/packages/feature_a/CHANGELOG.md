# Changelog

## [0.6.1](https://github.com/prefapp/features/compare/tech_docs-v0.6.0...tech_docs-v0.6.1) (2023-06-16)


### Bug Fixes

* Update tag used by renderer ([#192](https://github.com/prefapp/features/issues/192)) ([49d4968](https://github.com/prefapp/features/commit/49d49689deedcc4e4e9290a8698cf9d379054fa0))

## [0.6.0](https://github.com/prefapp/features/compare/tech_docs-v0.5.0...tech_docs-v0.6.0) (2023-06-08)


### Features

* release please ([#188](https://github.com/prefapp/features/issues/188)) ([20374e6](https://github.com/prefapp/features/commit/20374e6a01d658ddb2348fbc32b47241c1ae1647))

## [0.5.0](https://github.com/prefapp/features/compare/tech_docs-v0.4.0...tech_docs-v0.5.0) (2023-06-07)


### Features

* Add build-images ([#176](https://github.com/prefapp/features/issues/176)) ([d9e6e40](https://github.com/prefapp/features/commit/d9e6e40df7155d93138b105e9ca9f56d6c1ad02d))


### Bug Fixes

* Update upgradeable attribute name ([#171](https://github.com/prefapp/features/issues/171)) ([535c663](https://github.com/prefapp/features/commit/535c663a445368e600345c0b284df58542cfc72a))

## [0.4.0](https://github.com/prefapp/features/compare/tech_docs-v0.3.1...tech_docs-v0.4.0) (2023-05-24)


### Features

* Remove unused packages ([#153](https://github.com/prefapp/features/issues/153)) ([d12d28e](https://github.com/prefapp/features/commit/d12d28e71dc2d04fa63fd171985fd0a93e5a45c7))

## [0.3.1](https://github.com/prefapp/features/compare/tech_docs-v0.3.0...tech_docs-v0.3.1) (2023-05-04)


### Bug Fixes

* config.yaml from tech_docs ([9060afb](https://github.com/prefapp/features/commit/9060afba44fe88c4e3a20c1af2a995443acb158f))

## [0.3.0](https://github.com/prefapp/features/compare/tech_docs-v0.2.0...tech_docs-v0.3.0) (2023-05-04)


### Features

* Add back upgradable field ([#150](https://github.com/prefapp/features/issues/150)) ([e69be5b](https://github.com/prefapp/features/commit/e69be5b06409f0ee4d6ae57574b4eda8a3039f2d))


### Bug Fixes

* Tech docs config.yaml ([188d3b5](https://github.com/prefapp/features/commit/188d3b5c91751f4d8c2c378fb14fa6c054f8d070))

## [0.2.0](https://github.com/prefapp/features/compare/tech_docs-v0.1.0...tech_docs-v0.2.0) (2023-04-17)


### Features

* Feature/add tech docs ([#148](https://github.com/prefapp/features/issues/148)) ([8161681](https://github.com/prefapp/features/commit/8161681ffc1afa4417d46ae23eca45863c867abd))
