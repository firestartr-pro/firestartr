# Contributing to features

## Creating a new feature

To create new features follow the next steps:

1. Create a new branch from `main` with the name of the feature you want to create.
2. Create a new folder in `packages` with the name of the feature.
3. Create a `templates` folder.
5. Add the new feature to `.release-please-manifest.json` and `release-please-config.json`.
6. Create a `package.json` file using `npm init`.

The `config.yaml` file should have the following structure:

```yaml
feature_name: example
# The following are the args that will be used to render the templates, there are two types of args:
# $ref: This will be replaced by the value of the key in the metadata section of the config.yaml file
# $lit: This will be replaced by the value of the key in the args section of the config.yaml file
args:
  ORG:
    $ref: spec.provisioner.org
  REPO_NAME:
    $ref: metadata.name

# Files to render from the template folder
files:
  - src: mkdocs.yaml
    dest: mkdocs.yaml
    # If upgradable is true, it can be modified by the user. Therefore will not be overriden or deleted by the feature installer when an update or uninstall is performed. 
    upgradable: true
  - src: docs/index.md
    dest: docs/index.md
    upgradable: true

# Patches to apply in the componet catalog file using [JSON patch](https://www.rfc-editor.org/rfc/rfc6902) notation when the feature is installed
patches:
  - name: "add_annotation"
    op: "add"
    path: "/metadata/annotations/backstage.io~1techdocs-ref"
    # Values can be rendered the same way as the files
    value: "url:https://github.com/{{| ORG |}}/{{| REPO_NAME |}}/tree/main"

# Patches to apply in the componet catalog file using [JSON patch](https://www.rfc-editor.org/rfc/rfc6902) notation when the feature is uninstalled
unpatches:
  - name: "remove_annotation"
    op: "remove"
    path: "/metadata/annotations/backstage.io~1techdocs-ref"

```

### Template

To interpolate variables we are using [Mustache](https://mustache.github.io/mustache.5.html) template engine. Therefore, some extra logic can be added to the templates using conditionals:

```
{{|#condition|}}
  {{|variable|}}
{{|/condition|}}
{{|^condition|}}
  In case the condition is false
{{|/condition|}}
```

## Updating an existing feature

To create new features follow the next steps:

1. Create a new branch from `main`.
2. Modify the feature.
3. Merge the branch using a [conventional commit](https://www.conventionalcommits.org/en/v1.0.0/) to create a new release.

## Remove an existing feature

1. Create a new branch from `main`.
2. Remove the feature directory.
3. Remove the feature from `.release-please-manifest.json`.
4. Merge the branch using a [conventional commit](https://www.conventionalcommits.org/en/v1.0.0/) to create a new release.
