const { render } = require('@prefapp/firestarter-features_renderer').default;
const path = require('path');
const yaml = require('js-yaml');
const fs = require('fs');

test('Check that the rendered file works as expected', () => {

    const featurePath = path.join(__dirname, '..');
    const featureRenderPath = path.join('/tmp', Math.random().toString(36).substring(2, 15));

    const entityPath = path.join(__dirname, 'fixtures', 'component_a.yaml');
    const entity = yaml.load(fs.readFileSync(entityPath, 'utf8'));

    const expected_unmanaged_files = [
        ".dagger/pyproject.toml",
        ".dagger/poetry.lock",
        ".github/build_images.yml",
    ];

    const expected_managed_files = [
        "container-structure-test.yaml",
    ];

    const expected_output = {
        "files":expected_unmanaged_files.map((filePath) => {
            return {
              localPath: path.join(featureRenderPath, filePath),
              repoPath: filePath,
              userManaged: false,
            };
          }).concat(expected_managed_files.map((filePath) => {
            return {
              localPath: path.join(featureRenderPath, filePath),
              repoPath: filePath,
              userManaged: true,
            };
          })),
        "patches":[],
        "unpatches":[]
    };


    render(featurePath, featureRenderPath, entity);

    const output = JSON.parse(fs.readFileSync(path.join(featureRenderPath, 'output.json'), 'utf8'));
    expect(output).toStrictEqual(expected_output);

    [...expected_unmanaged_files, ...expected_managed_files].forEach((filePath) => {
        expect(fs.existsSync(path.join(featureRenderPath, filePath))).toBe(true);
    });


});
