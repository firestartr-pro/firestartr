# Changelog

## [1.0.1](https://github.com/prefapp/features/compare/release_please-v1.0.0...release_please-v1.0.1) (2023-06-16)


### Bug Fixes

* Update tag used by renderer ([#192](https://github.com/prefapp/features/issues/192)) ([49d4968](https://github.com/prefapp/features/commit/49d49689deedcc4e4e9290a8698cf9d379054fa0))

## [1.0.0](https://github.com/prefapp/features/compare/release_please-v0.1.0...release_please-v1.0.0) (2023-06-08)


### ⚠ BREAKING CHANGES

* Add release please feature to release please ([#190](https://github.com/prefapp/features/issues/190))

### Features

* release please ([#188](https://github.com/prefapp/features/issues/188)) ([20374e6](https://github.com/prefapp/features/commit/20374e6a01d658ddb2348fbc32b47241c1ae1647))


### Bug Fixes

* Add release please feature to release please ([#190](https://github.com/prefapp/features/issues/190)) ([b1d891d](https://github.com/prefapp/features/commit/b1d891df101cc337dac4e35b99cb5bba33ecf9dd))
