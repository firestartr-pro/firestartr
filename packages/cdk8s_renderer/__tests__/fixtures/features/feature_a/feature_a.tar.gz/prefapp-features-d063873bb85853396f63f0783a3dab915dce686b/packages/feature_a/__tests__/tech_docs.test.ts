const { render } = require('@prefapp/firestarter-features_renderer').default;
const path = require('path');
const yaml = require('js-yaml');
const fs = require('fs');

test('Rendering works as expected', () => {
    
    const featurePath = path.join(__dirname, '..');
    const featureRenderPath = path.join('/tmp', Math.random().toString(36).substring(2, 15));

    const entityPath = path.join(__dirname, 'fixtures', 'component_a.yaml');
    const entity = yaml.load(fs.readFileSync(entityPath, 'utf8'));

    const configObject = yaml.load(fs.readFileSync(path.join(__dirname, '../config.yaml')));

    configObject.patches[0].value = configObject.patches[0].value.replace(
        '{{| ORG |}}', 'prefapp'
    ).replace('{{| REPO_NAME |}}', 'component_a');

    const expected_created_files = [
        "mkdocs.yaml",
        "docs/index.md",
    ];

    const expectedOutput = {
        "files":expected_created_files.map((filePath) => {
            return {
              localPath: path.join(featureRenderPath, filePath),
              repoPath: filePath,
              userManaged: true,
            };
          }),
        "patches": configObject.patches,
        "unpatches":configObject.unpatches,
    };

    render(featurePath, featureRenderPath, entity);

    const output = JSON.parse(fs.readFileSync(path.join(featureRenderPath, 'output.json'), 'utf8'));

    expect(output).toStrictEqual(expectedOutput);

    expected_created_files.forEach((filePath) => {
        expect(fs.existsSync(path.join(featureRenderPath, filePath))).toBe(true);
    });


});
