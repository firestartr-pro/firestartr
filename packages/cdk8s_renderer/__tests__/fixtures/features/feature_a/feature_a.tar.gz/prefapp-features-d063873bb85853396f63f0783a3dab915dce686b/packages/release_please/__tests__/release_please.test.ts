const firestarterRenderer = require("@prefapp/firestarter-features_renderer").default
const path = require('path');
const fs = require('fs');
const yaml = require('js-yaml');

test('Release Please Render', () => {

    const featurePath = path.join(__dirname, '..');

    const entityPath = path.join(__dirname, 'fixtures', 'component_a.yaml');

    const entity = yaml.load(fs.readFileSync(entityPath, 'utf8'));

    firestarterRenderer.render(featurePath, "/tmp/release_please_test_render", entity)

    expect(fs.existsSync("/tmp/release_please_test_render/.release-please-manifest.json")).toBe(true)

    const renderedWorkflow = fs.readFileSync("/tmp/release_please_test_render/.github/workflows/release-please.yaml", 'utf8');

    expect(renderedWorkflow.includes("main")).toBe(true)

    expect(fs.existsSync("/tmp/release_please_test_render/release-please-config.json")).toBe(true)

    expect(fs.existsSync("/tmp/release_please_test_render/.github/workflows/release-please.yaml")).toBe(true)

    //remove the folder
    fs.rmdirSync("/tmp/release_please_test_render", { recursive: true });

});
