# Changelog

## [1.1.0](https://github.com/prefapp/features/compare/build_images-v1.0.1...build_images-v1.1.0) (2023-06-08)


### Features

* release please ([#188](https://github.com/prefapp/features/issues/188)) ([20374e6](https://github.com/prefapp/features/commit/20374e6a01d658ddb2348fbc32b47241c1ae1647))

## [1.0.1](https://github.com/prefapp/features/compare/build_images-v1.0.0...build_images-v1.0.1) (2023-06-07)


### Bug Fixes

* Fix workflow filename ([#183](https://github.com/prefapp/features/issues/183)) ([bd742c2](https://github.com/prefapp/features/commit/bd742c2d4fb739220721966050561c0252a47009))

## 1.0.0 (2023-06-07)


### Features

* Add build-images ([#176](https://github.com/prefapp/features/issues/176)) ([d9e6e40](https://github.com/prefapp/features/commit/d9e6e40df7155d93138b105e9ca9f56d6c1ad02d))


### Bug Fixes

* Add package json for issues templates ([#181](https://github.com/prefapp/features/issues/181)) ([f65d98a](https://github.com/prefapp/features/commit/f65d98a44cafcdf75135f6a2b4f018dc16fddff1))
